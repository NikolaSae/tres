import { ErrorCard } from "@/components/auth/error-card";

export default function ErrorPage() {
  return <ErrorCard />;
}
